import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFF243B53); // Navy dark
const Color kSecondaryColor = Color(0xFFCDE8F4); // Biru muda
const Color kAccentColor = Color(0xFFFFA500); // Oranye logo
const Color kBackgroundColor = Color(0xFFFAF3DD); // Kuning Tua Krem
const Color kTextColor = Color(0xFF1F2937); // Abu-hitam
