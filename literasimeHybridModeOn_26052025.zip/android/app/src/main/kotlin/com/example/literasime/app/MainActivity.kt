package com.literasime.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
